package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayTextActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_text);

        // Mendapatkan data dari Intent (teks yang dikirim)
        String receivedText = getIntent().getStringExtra("user_text");

        // Menampilkan teks yang diterima di TextView
        TextView textView = findViewById(R.id.displayTextView);
        textView.setText(receivedText);
    }
}
