package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        Button openDialerButton = findViewById(R.id.openDialerButton);
        openDialerButton.setOnClickListener(v -> {
            // Implicit Intent untuk membuka Dialer
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:123456789"));  // Ganti nomor sesuai kebutuhan
            startActivity(dialIntent);
        });

        Button openMapButton = findViewById(R.id.openMapButton);
        openMapButton.setOnClickListener(v -> {
            // Implicit Intent untuk membuka Google Maps
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=latitude,longitude"));  // Ganti koordinat lokasi
            startActivity(mapIntent);
        });
    }
}
