package com.example.sakuku;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StatisticsActivity extends AppCompatActivity {

    private TextView statisticsPlaceholder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);  // Pastikan layout ini ada

        statisticsPlaceholder = findViewById(R.id.statisticsPlaceholder);

        // Menampilkan pesan placeholder
        statisticsPlaceholder.setText("Grafik Statistik");  // Menampilkan teks sebagai placeholder
    }
}
