package com.example.sakuku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button tambahPemasukanButton;
    private Button tambahPengeluaranButton;
    private Button statistikButton;
    private Button reminderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tambahPemasukanButton = findViewById(R.id.tambahPemasukanButton);
        tambahPengeluaranButton = findViewById(R.id.tambahPengeluaranButton);
        statistikButton = findViewById(R.id.statistikButton);
        reminderButton = findViewById(R.id.reminderButton);

        tambahPemasukanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aksi untuk menambah pemasukan
            }
        });

        tambahPengeluaranButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aksi untuk menambah pengeluaran
            }
        });

        statistikButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aksi untuk melihat statistik keuangan
            }
        });

        reminderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aksi untuk membuka pengingat
                Intent intent = new Intent(MainActivity.this, ReminderActivity.class);
                startActivity(intent);
            }
        });
    }
}
