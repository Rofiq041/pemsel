package com.example.praktikum4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FragmentActivity extends AppCompatActivity {

    Button buttonShowFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        buttonShowFragment = findViewById(R.id.buttonShowFragment);

        buttonShowFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tampilkan SimpleFragment
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainer, new SimpleFragment())
                        .commit();
            }
        });
    }
}
