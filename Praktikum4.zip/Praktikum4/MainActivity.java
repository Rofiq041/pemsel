package com.example.praktikum4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button buttonNext, buttonFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonNext = findViewById(R.id.buttonNext);
        buttonFragment = findViewById(R.id.buttonFragment);

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke FragmentActivity
                startActivity(new Intent(MainActivity.this, FragmentActivity.class));
            }
        });

        buttonFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Optional: bisa tampilkan fragment di MainActivity
                // Tapi karena layout MainActivity ga punya container, bisa kasih toast dulu
                // Bisa dikembangkan sesuai kebutuhan
            }
        });
    }
}
